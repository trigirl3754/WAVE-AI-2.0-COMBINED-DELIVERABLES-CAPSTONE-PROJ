import React, { useState } from "react";
import {
  ShieldCheck,
  ShieldAlert,
  ShieldX,
  Bot,
  UserCheck,
  Users,
  ClipboardList,
  ChevronDown,
  ChevronRight,
  ArrowRight,
  OctagonAlert,
  CircleAlert,
  FileWarning,
  Eye,
  Scale,
  Landmark,
} from "lucide-react";

/* -------------------------------------------------------------------------
 * TYPES
 * ---------------------------------------------------------------------- */

type Verdict = "ai" | "assist" | "human";

interface OpportunityRow {
  task: string;
  why: string;
  verdict: Verdict;
  verdictLabel: string;
}

interface VerificationRow {
  produces: string;
  checks: string;
}

type Priority = "high" | "medium" | "low";

interface RiskRow {
  risk: string;
  likelihood: "Low" | "Medium" | "High";
  impact: "Low" | "Medium" | "High";
  priority: Priority;
  priorityLabel: string;
  rationale: string;
}

type RaciValue = "R" | "A" | "C" | "I" | "R,A" | "—";

interface RaciRow {
  task: string;
  aiSystem: RaciValue;
  investigator: RaciValue;
  complianceManager: RaciValue;
  auditor: RaciValue;
}

interface WorkflowStep {
  step: number;
  label: string;
  actor: "ai" | "human" | "system";
  checkpoint?: number; // 1, 2, or 3
  branch?: string;
}

/* -------------------------------------------------------------------------
 * DATA — edit these arrays to update the content; layout follows automatically
 * ---------------------------------------------------------------------- */

const opportunityRows: OpportunityRow[] = [
  {
    task: "Summarize transaction history",
    why: "AI just reads & summarizes data — easy to spot mistakes",
    verdict: "ai",
    verdictLabel: "Good idea for AI",
  },
  {
    task: "Summarize customer profile",
    why: "Same — low risk, saves time",
    verdict: "ai",
    verdictLabel: "Good idea for AI",
  },
  {
    task: "Spot suspicious patterns",
    why: "Helpful flagging, human still reviews it",
    verdict: "ai",
    verdictLabel: "Good idea for AI",
  },
  {
    task: "Calculate a risk score",
    why: "Speeds things up, human sees reasoning before acting",
    verdict: "ai",
    verdictLabel: "Good idea for AI",
  },
  {
    task: "Recommend next action (escalate/close/review)",
    why: "AI only suggests — human clicks the final button",
    verdict: "ai",
    verdictLabel: "Good idea for AI",
  },
  {
    task: "Draft the SAR report",
    why: "Real legal document — mistakes matter a lot",
    verdict: "assist",
    verdictLabel: "AI helps, human must check",
  },
  {
    task: "Close an investigation",
    why: "Final decision, real consequences",
    verdict: "human",
    verdictLabel: "Humans only",
  },
  {
    task: "Submit a SAR to regulators",
    why: "Legal filing — must be human-approved",
    verdict: "human",
    verdictLabel: "Humans only",
  },
  {
    task: "Freeze a bank account",
    why: "Direct financial action on a real person",
    verdict: "human",
    verdictLabel: "Humans only",
  },
  {
    task: "Approve an escalation",
    why: "Affects what happens to a real case",
    verdict: "human",
    verdictLabel: "Humans only",
  },
];

const verificationRows: VerificationRow[] = [
  {
    produces: "Risk score",
    checks: "Does this score actually match the evidence given?",
  },
  {
    produces: "Case summary",
    checks: "Did it miss anything important, or invent something not in the data?",
  },
  {
    produces: "Recommendation (escalate/close/review)",
    checks: "Does this match the risk score and summary, or contradict them?",
  },
  {
    produces: "SAR draft",
    checks: "Are required fields complete? Any factual mismatches with the case data?",
  },
];

const riskRows: RiskRow[] = [
  {
    risk: "AI hallucination",
    likelihood: "Medium",
    impact: "High",
    priority: "high",
    priorityLabel: "High",
    rationale:
      "AI language models are known to occasionally generate plausible but false details, especially when summarizing large amounts of data — a documented limitation, not something we tested ourselves",
  },
  {
    risk: "Wrong risk score",
    likelihood: "Medium",
    impact: "High",
    priority: "high",
    priorityLabel: "High",
    rationale:
      "Risk scoring involves judgment calls; AI can misweigh factors or miss context a human would catch, leading to false negatives (missed real risk)",
  },
  {
    risk: "Biased recommendations",
    likelihood: "Low",
    impact: "High",
    priority: "medium",
    priorityLabel: "Medium",
    rationale:
      "AI models can reflect patterns from training data that unintentionally disadvantage certain groups — a known industry concern in AI fairness, even if not yet observed in our system",
  },
  {
    risk: "Automation bias",
    likelihood: "High",
    impact: "Medium",
    priority: "medium",
    priorityLabel: "Medium",
    rationale:
      "Well-documented in human-AI collaboration research: people tend to over-trust automated suggestions over time, especially under time pressure — a behavioral risk, not a system bug",
  },
  {
    risk: "SAR draft errors",
    likelihood: "Medium",
    impact: "High",
    priority: "high",
    priorityLabel: "High",
    rationale:
      "Legal/regulatory documents require precision; an AI draft with a wrong detail could pass review if the human reviewer skims rather than verifies",
  },
  {
    risk: "AI #2 (verifier) misses an error",
    likelihood: "Low",
    impact: "Medium",
    priority: "low",
    priorityLabel: "Low",
    rationale:
      "The verification layer reduces but doesn't eliminate risk — two AI systems can share similar blind spots since they may be built on similar underlying models",
  },
  {
    risk: "System downtime",
    likelihood: "Low",
    impact: "Medium",
    priority: "low",
    priorityLabel: "Low",
    rationale:
      "Cloud-based AI services generally have high uptime, but outages do happen and would temporarily block investigator workflows",
  },
  {
    risk: "Data privacy leak",
    likelihood: "Low",
    impact: "High",
    priority: "medium",
    priorityLabel: "Medium",
    rationale:
      "Handling sensitive financial/PII data always carries exposure risk if logging, masking, or access controls aren't properly enforced",
  },
];

const raciRoleLabels = ["AI System", "Investigator", "Compliance Manager", "Auditor"] as const;

const raciRows: RaciRow[] = [
  { task: "Generate risk score", aiSystem: "R", investigator: "I", complianceManager: "C", auditor: "I" },
  { task: "Summarize case (transactions/customer)", aiSystem: "R", investigator: "I", complianceManager: "—", auditor: "—" },
  { task: "Generate recommendation", aiSystem: "R", investigator: "C", complianceManager: "—", auditor: "—" },
  { task: "Review case & make decision", aiSystem: "C", investigator: "R,A", complianceManager: "I", auditor: "—" },
  { task: "Approve escalation", aiSystem: "I", investigator: "R", complianceManager: "A", auditor: "I" },
  { task: "Draft SAR", aiSystem: "R", investigator: "C", complianceManager: "I", auditor: "—" },
  { task: "Review & edit SAR", aiSystem: "C", investigator: "R,A", complianceManager: "C", auditor: "I" },
  { task: "Approve SAR submission", aiSystem: "I", investigator: "I", complianceManager: "R,A", auditor: "I" },
  { task: "Close investigation", aiSystem: "I", investigator: "R,A", complianceManager: "I", auditor: "—" },
  { task: "Maintain audit logs", aiSystem: "R", investigator: "I", complianceManager: "I", auditor: "A" },
  { task: "Review governance/compliance", aiSystem: "I", investigator: "I", complianceManager: "C", auditor: "R,A" },
];

const raciLegend = [
  { letter: "R", label: "Responsible", desc: "who actually does the work" },
  { letter: "A", label: "Accountable", desc: "who's ultimately on the hook if it goes wrong (usually just one role)" },
  { letter: "C", label: "Consulted", desc: "who gives input before it happens" },
  { letter: "I", label: "Informed", desc: "who just needs to know after it happens" },
];

const raciRoles = [
  { name: "AI System", detail: "Risk Engine + Investigator Copilot" },
  { name: "Investigator", detail: "Owns day-to-day case decisions" },
  { name: "Compliance Manager", detail: "Owns approvals with legal weight" },
  { name: "Auditor", detail: "Owns oversight of the whole system" },
];

const workflowSteps: WorkflowStep[] = [
  { step: 1, label: "Alert comes in", actor: "system" },
  { step: 2, label: "AI scores the risk", actor: "ai" },
  { step: 3, label: "AI #2 checks the score (verification layer)", actor: "ai" },
  { step: 4, label: "AI summarizes the case", actor: "ai" },
  { step: 5, label: "AI recommends an action", actor: "ai" },
  {
    step: 6,
    label: "Investigator reviews everything, decides: Close / Escalate / Need more info",
    actor: "human",
    checkpoint: 1,
    branch: "If Close → case closes, logged.  If Escalate → goes to SAR drafting.",
  },
  { step: 7, label: "AI drafts the SAR", actor: "ai" },
  {
    step: 8,
    label: "Investigator edits/reviews the draft",
    actor: "human",
    checkpoint: 2,
  },
  {
    step: 9,
    label: "Compliance Manager approves submission",
    actor: "human",
    checkpoint: 3,
  },
  { step: 10, label: "Everything is logged — Auditor has visibility", actor: "system" },
];

/* -------------------------------------------------------------------------
 * STYLE HELPERS (color semantics kept consistent with the .docx deliverable)
 *   green/emerald = good fit for AI / low priority
 *   amber         = AI assists but human must verify / medium priority
 *   red/rose      = human authority only / high priority / mandatory checkpoint
 *   navy/slate    = headers, structural elements
 *   blue          = AI-executed steps, accent color, links
 * ---------------------------------------------------------------------- */

const verdictStyles: Record<Verdict, { badge: string; row: string; icon: React.ReactNode }> = {
  ai: {
    badge: "bg-emerald-50 text-emerald-800 ring-1 ring-emerald-200",
    row: "border-l-4 border-emerald-400",
    icon: <ShieldCheck className="h-4 w-4 text-emerald-600 shrink-0" />,
  },
  assist: {
    badge: "bg-amber-50 text-amber-800 ring-1 ring-amber-200",
    row: "border-l-4 border-amber-400",
    icon: <ShieldAlert className="h-4 w-4 text-amber-600 shrink-0" />,
  },
  human: {
    badge: "bg-rose-50 text-rose-800 ring-1 ring-rose-200",
    row: "border-l-4 border-rose-400",
    icon: <ShieldX className="h-4 w-4 text-rose-600 shrink-0" />,
  },
};

const priorityStyles: Record<Priority, string> = {
  high: "bg-rose-50 text-rose-800 ring-1 ring-rose-200",
  medium: "bg-orange-50 text-orange-800 ring-1 ring-orange-200",
  low: "bg-amber-50 text-amber-800 ring-1 ring-amber-200",
};

function levelDot(level: "Low" | "Medium" | "High") {
  const map = { Low: "bg-slate-300", Medium: "bg-slate-500", High: "bg-slate-800" };
  return <span className={`inline-block h-2 w-2 rounded-full ${map[level]} mr-1.5`} />;
}

function RaciCell({ value }: { value: RaciValue }) {
  const hasA = value.includes("A");
  if (value === "—") {
    return <span className="text-slate-300">—</span>;
  }
  return (
    <span
      className={
        hasA
          ? "font-bold text-rose-700"
          : "text-slate-600 font-medium"
      }
    >
      {value}
    </span>
  );
}

/* -------------------------------------------------------------------------
 * SECTION: Opportunity Matrix
 * ---------------------------------------------------------------------- */

function OpportunityMatrix() {
  const [expanded, setExpanded] = useState<number | null>(null);

  return (
    <section className="mb-14">
      <SectionHeader
        eyebrow="01 — Opportunity Matrix"
        title="What can AI actually do here?"
        subtitle="A per-task verdict on where AI is a good fit, where it needs a human check, and where only a human may act."
      />

      {/* Desktop / tablet table */}
      <div className="hidden sm:block overflow-hidden rounded-xl ring-1 ring-slate-200">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-slate-900 text-white text-left">
              <th className="px-4 py-3 font-semibold w-[30%]">AI Task</th>
              <th className="px-4 py-3 font-semibold">Why</th>
              <th className="px-4 py-3 font-semibold w-[190px]">Verdict</th>
            </tr>
          </thead>
          <tbody>
            {opportunityRows.map((row, i) => (
              <tr
                key={row.task}
                className={`${verdictStyles[row.verdict].row} ${
                  i % 2 === 0 ? "bg-white" : "bg-slate-50"
                }`}
              >
                <td className="px-4 py-3 align-top font-medium text-slate-900">{row.task}</td>
                <td className="px-4 py-3 align-top text-slate-600">{row.why}</td>
                <td className="px-4 py-3 align-top">
                  <span
                    className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold ${
                      verdictStyles[row.verdict].badge
                    }`}
                  >
                    {verdictStyles[row.verdict].icon}
                    {row.verdictLabel}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile: collapsible "Why" */}
      <div className="sm:hidden space-y-2">
        {opportunityRows.map((row, i) => (
          <div
            key={row.task}
            className={`rounded-lg bg-white ring-1 ring-slate-200 ${verdictStyles[row.verdict].row}`}
          >
            <button
              className="w-full text-left px-4 py-3 flex items-start justify-between gap-2"
              onClick={() => setExpanded(expanded === i ? null : i)}
            >
              <div>
                <p className="font-medium text-slate-900 text-sm">{row.task}</p>
                <span
                  className={`mt-1.5 inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-xs font-semibold ${
                    verdictStyles[row.verdict].badge
                  }`}
                >
                  {verdictStyles[row.verdict].icon}
                  {row.verdictLabel}
                </span>
              </div>
              {expanded === i ? (
                <ChevronDown className="h-4 w-4 text-slate-400 shrink-0 mt-1" />
              ) : (
                <ChevronRight className="h-4 w-4 text-slate-400 shrink-0 mt-1" />
              )}
            </button>
            {expanded === i && (
              <p className="px-4 pb-3 text-sm text-slate-600 border-t border-slate-100 pt-2">{row.why}</p>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}

/* -------------------------------------------------------------------------
 * SECTION: Verification Layer
 * ---------------------------------------------------------------------- */

function VerificationLayer() {
  return (
    <section className="mb-14">
      <SectionHeader
        eyebrow="02 — Verification Layer"
        title="AI checking AI"
        subtitle="Sits between AI output and human review — it's a quality check, not a decision-maker."
      />

      <div className="overflow-x-auto rounded-xl ring-1 ring-slate-200">
        <table className="w-full text-sm min-w-[560px]">
          <thead>
            <tr className="bg-slate-900 text-white text-left">
              <th className="px-4 py-3 font-semibold w-[35%]">What AI #1 Produces</th>
              <th className="px-4 py-3 font-semibold">What AI #2 (Verifier) Checks</th>
            </tr>
          </thead>
          <tbody>
            {verificationRows.map((row, i) => (
              <tr key={row.produces} className={i % 2 === 0 ? "bg-white" : "bg-slate-50"}>
                <td className="px-4 py-3 align-top font-medium text-slate-900 border-l-4 border-blue-400">
                  {row.produces}
                </td>
                <td className="px-4 py-3 align-top text-slate-600">{row.checks}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-5 flex flex-wrap items-center gap-2 rounded-xl bg-blue-50 ring-1 ring-blue-100 px-5 py-4 text-sm font-medium text-slate-800">
        <span className="inline-flex items-center gap-1.5 rounded-lg bg-white px-3 py-1.5 ring-1 ring-blue-200">
          <Bot className="h-4 w-4 text-blue-600" /> AI #1 <span className="text-slate-500 font-normal">(does the work)</span>
        </span>
        <ArrowRight className="h-4 w-4 text-slate-400" />
        <span className="inline-flex items-center gap-1.5 rounded-lg bg-white px-3 py-1.5 ring-1 ring-blue-200">
          <Eye className="h-4 w-4 text-blue-600" /> AI #2 <span className="text-slate-500 font-normal">(checks the work)</span>
        </span>
        <ArrowRight className="h-4 w-4 text-slate-400" />
        <span className="inline-flex items-center gap-1.5 rounded-lg bg-white px-3 py-1.5 ring-1 ring-rose-200">
          <UserCheck className="h-4 w-4 text-rose-600" /> Human <span className="text-slate-500 font-normal">(makes the final call)</span>
        </span>
      </div>
    </section>
  );
}

/* -------------------------------------------------------------------------
 * SECTION: Risk Matrix
 * ---------------------------------------------------------------------- */

function RiskMatrix() {
  return (
    <section className="mb-14">
      <SectionHeader
        eyebrow="03 — Risk Matrix"
        title="What could go wrong, and how much does it matter"
        subtitle="Each risk rated Likelihood × Impact → Priority, with rationale for the call."
      />

      <div className="overflow-x-auto rounded-xl ring-1 ring-slate-200">
        <table className="w-full text-sm min-w-[760px]">
          <thead>
            <tr className="bg-slate-900 text-white text-left">
              <th className="px-4 py-3 font-semibold w-[16%]">Risk</th>
              <th className="px-4 py-3 font-semibold w-[110px]">Likelihood</th>
              <th className="px-4 py-3 font-semibold w-[100px]">Impact</th>
              <th className="px-4 py-3 font-semibold w-[110px]">Priority</th>
              <th className="px-4 py-3 font-semibold">Rationale</th>
            </tr>
          </thead>
          <tbody>
            {riskRows.map((row, i) => (
              <tr
                key={row.risk}
                className={`${i % 2 === 0 ? "bg-white" : "bg-slate-50"} ${
                  row.priority === "high"
                    ? "border-l-4 border-rose-400"
                    : row.priority === "medium"
                    ? "border-l-4 border-orange-400"
                    : "border-l-4 border-amber-300"
                }`}
              >
                <td className="px-4 py-3 align-top font-medium text-slate-900">{row.risk}</td>
                <td className="px-4 py-3 align-top text-slate-600">
                  {levelDot(row.likelihood)}
                  {row.likelihood}
                </td>
                <td className="px-4 py-3 align-top text-slate-600">
                  {levelDot(row.impact)}
                  {row.impact}
                </td>
                <td className="px-4 py-3 align-top">
                  <span
                    className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold ${priorityStyles[row.priority]}`}
                  >
                    {row.priorityLabel}
                  </span>
                </td>
                <td className="px-4 py-3 align-top text-slate-600">{row.rationale}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}

/* -------------------------------------------------------------------------
 * SECTION: RACI Model
 * ---------------------------------------------------------------------- */

function RaciModel() {
  return (
    <section className="mb-14">
      <SectionHeader
        eyebrow="04 — RACI Model"
        title="For each task, who does what?"
        subtitle="Only one Accountable role per task — accountability can't be shared."
      />

      {/* legend */}
      <div className="mb-6 grid grid-cols-2 md:grid-cols-4 gap-3">
        {raciLegend.map((l) => (
          <div key={l.letter} className="rounded-lg bg-slate-50 ring-1 ring-slate-200 px-3 py-2.5">
            <span
              className={`text-sm font-bold ${l.letter === "A" ? "text-rose-700" : "text-slate-700"}`}
            >
              {l.letter}
            </span>
            <span className="ml-1.5 text-sm font-semibold text-slate-800">{l.label}</span>
            <p className="text-xs text-slate-500 mt-0.5">{l.desc}</p>
          </div>
        ))}
      </div>

      {/* roles */}
      <div className="mb-6 grid grid-cols-2 md:grid-cols-4 gap-3">
        {raciRoles.map((r) => (
          <div key={r.name} className="rounded-lg bg-white ring-1 ring-slate-200 px-3 py-2.5">
            <p className="text-sm font-semibold text-slate-900">{r.name}</p>
            <p className="text-xs text-slate-500 mt-0.5">{r.detail}</p>
          </div>
        ))}
      </div>

      <div className="overflow-x-auto rounded-xl ring-1 ring-slate-200">
        <table className="w-full text-sm min-w-[640px]">
          <thead>
            <tr className="bg-slate-900 text-white text-left">
              <th className="px-4 py-3 font-semibold w-[34%]">Task</th>
              {raciRoleLabels.map((label) => (
                <th key={label} className="px-4 py-3 font-semibold text-center">
                  {label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {raciRows.map((row, i) => (
              <tr key={row.task} className={i % 2 === 0 ? "bg-white" : "bg-slate-50"}>
                <td className="px-4 py-3 align-top font-medium text-slate-900">{row.task}</td>
                <td className="px-4 py-3 align-top text-center">
                  <RaciCell value={row.aiSystem} />
                </td>
                <td className="px-4 py-3 align-top text-center">
                  <RaciCell value={row.investigator} />
                </td>
                <td className="px-4 py-3 align-top text-center">
                  <RaciCell value={row.complianceManager} />
                </td>
                <td className="px-4 py-3 align-top text-center">
                  <RaciCell value={row.auditor} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-6 rounded-xl bg-slate-50 ring-1 ring-slate-200 px-5 py-4">
        <p className="text-sm font-semibold text-slate-900 mb-2">What to notice</p>
        <ul className="space-y-1.5 text-sm text-slate-600">
          <li className="flex gap-2">
            <Bot className="h-4 w-4 text-slate-400 shrink-0 mt-0.5" />
            AI is never the "A" (Accountable) on anything — it's always R (does the work) or C/I
            (gives input / is informed).
          </li>
          <li className="flex gap-2">
            <UserCheck className="h-4 w-4 text-slate-400 shrink-0 mt-0.5" />
            Humans are always Accountable for real decisions — the human-in-the-loop principle
            made concrete, not just a slogan.
          </li>
          <li className="flex gap-2">
            <Users className="h-4 w-4 text-slate-400 shrink-0 mt-0.5" />
            The Investigator owns day-to-day decisions; the Compliance Manager owns approvals
            with legal weight (SAR submission, escalation); the Auditor owns oversight of the
            whole system.
          </li>
        </ul>
      </div>
    </section>
  );
}

/* -------------------------------------------------------------------------
 * SECTION: Human-in-the-Loop Workflow
 * ---------------------------------------------------------------------- */

function actorStyle(actor: WorkflowStep["actor"]) {
  if (actor === "ai") {
    return { bg: "bg-blue-50", ring: "ring-blue-200", icon: <Bot className="h-4 w-4 text-blue-600" />, tag: "AI" };
  }
  if (actor === "human") {
    return { bg: "bg-rose-50", ring: "ring-rose-300", icon: <UserCheck className="h-4 w-4 text-rose-600" />, tag: "Human checkpoint" };
  }
  return { bg: "bg-slate-100", ring: "ring-slate-200", icon: <ClipboardList className="h-4 w-4 text-slate-500" />, tag: "System" };
}

function Workflow() {
  return (
    <section className="mb-6">
      <SectionHeader
        eyebrow="05 — Human-in-the-Loop Workflow"
        title="The exact path a case takes"
        subtitle="AI runs several legs of the relay, but it has to hand the baton to a human at three checkpoints — the race can't continue until the human says go."
      />

      <ol className="relative border-l-2 border-slate-200 ml-3 space-y-4">
        {workflowSteps.map((s) => {
          const style = actorStyle(s.actor);
          const isCheckpoint = !!s.checkpoint;
          return (
            <li key={s.step} className="relative pl-8">
              <span
                className={`absolute -left-[9px] top-1.5 h-4 w-4 rounded-full ring-4 ring-white ${
                  isCheckpoint ? "bg-rose-600" : s.actor === "ai" ? "bg-blue-500" : "bg-slate-400"
                }`}
              />
              <div className={`rounded-xl ${style.bg} ${isCheckpoint ? "ring-2" : "ring-1"} ${style.ring} px-4 py-3`}>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs font-semibold text-slate-400">STEP {s.step}</span>
                  <span
                    className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-bold uppercase tracking-wide ${
                      isCheckpoint
                        ? "bg-rose-600 text-white"
                        : s.actor === "ai"
                        ? "bg-blue-600 text-white"
                        : "bg-slate-500 text-white"
                    }`}
                  >
                    {isCheckpoint ? (
                      <>
                        <OctagonAlert className="h-3 w-3" /> Checkpoint {s.checkpoint}
                      </>
                    ) : (
                      <>
                        {style.icon}
                        {style.tag}
                      </>
                    )}
                  </span>
                </div>
                <p className={`mt-1.5 text-sm ${isCheckpoint ? "font-semibold text-rose-900" : "text-slate-800 font-medium"}`}>
                  {s.label}
                </p>
                {s.branch && (
                  <p className="mt-1.5 text-xs text-slate-500 border-t border-slate-200/70 pt-1.5">{s.branch}</p>
                )}
              </div>
            </li>
          );
        })}
      </ol>
    </section>
  );
}

/* -------------------------------------------------------------------------
 * SHARED
 * ---------------------------------------------------------------------- */

function SectionHeader({
  eyebrow,
  title,
  subtitle,
}: {
  eyebrow: string;
  title: string;
  subtitle: string;
}) {
  return (
    <div className="mb-6">
      <p className="text-xs font-bold uppercase tracking-widest text-blue-600">{eyebrow}</p>
      <h2 className="mt-1 text-2xl font-bold text-slate-900">{title}</h2>
      <p className="mt-1.5 text-sm text-slate-500 max-w-2xl">{subtitle}</p>
    </div>
  );
}

/* -------------------------------------------------------------------------
 * ROOT COMPONENT
 * ---------------------------------------------------------------------- */

export default function HumanGovernanceModel() {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-slate-900 text-white">
        <div className="max-w-5xl mx-auto px-6 py-10">
          <div className="flex items-center gap-2 text-blue-300 text-xs font-bold uppercase tracking-widest">
            <Landmark className="h-4 w-4" />
            WAVE AI Investigator Co-Pilot
          </div>
          <h1 className="mt-2 text-3xl sm:text-4xl font-bold tracking-tight">
            Human Governance Model
          </h1>
          <p className="mt-4 max-w-2xl text-slate-300 text-sm sm:text-base leading-relaxed">
            AI accelerates analysis and drafting; it never holds final authority over an outcome
            that affects a real person, account, or regulatory filing. Accountability always sits
            with a named human role.
          </p>

          <div className="mt-6 flex flex-wrap gap-3 text-xs">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-1.5 ring-1 ring-white/20">
              <Scale className="h-3.5 w-3.5 text-blue-300" /> Transaction monitoring / SAR investigations
            </span>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-1.5 ring-1 ring-white/20">
              <FileWarning className="h-3.5 w-3.5 text-rose-300" /> 3 mandatory human checkpoints
            </span>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-1.5 ring-1 ring-white/20">
              <CircleAlert className="h-3.5 w-3.5 text-amber-300" /> AI is never "Accountable"
            </span>
          </div>
        </div>
      </header>

      {/* Body */}
      <main className="max-w-5xl mx-auto px-6 py-12">
        <OpportunityMatrix />
        <VerificationLayer />
        <RiskMatrix />
        <RaciModel />
        <Workflow />
      </main>

      <footer className="border-t border-slate-200 py-8">
        <div className="max-w-5xl mx-auto px-6 text-xs text-slate-400">
          WAVE AI Investigator Co-Pilot — Human Governance Model
        </div>
      </footer>
    </div>
  );
}
